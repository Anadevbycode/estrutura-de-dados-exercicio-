#include <stdio.h>

int main() {
    int n;

    printf("Digite o valor de n: ");
    scanf("%d", &n);

    if (n < 0) {
        printf("O valor de n n�o pode ser negativo.\n");
    } else {
        printf("Com o comando while:\n");
        int i = 0;
        while (i < n) {
            printf("*");
            i++;
        }
        printf("\n");
    }

    return 0;
}
